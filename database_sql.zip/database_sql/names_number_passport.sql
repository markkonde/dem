-- phpMyAdmin SQL Dump
-- version 4.0.9
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 04, 2018 at 12:31 PM
-- Server version: 5.6.14
-- PHP Version: 5.5.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `names_number_passport`
--

-- --------------------------------------------------------

--
-- Table structure for table `info_table`
--

CREATE TABLE IF NOT EXISTS `info_table` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `passport` varchar(25) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `info_table`
--

INSERT INTO `info_table` (`ID`, `name`, `phone`, `passport`) VALUES
(4, 'konde mark', '+122 544131253', '0_1530699777.jpeg'),
(5, 'konde alex', '+122 544131253', '1_1530699777.jpeg'),
(6, 'konde faustina', '+122 544131253', '2_1530699777.jpeg'),
(7, 'john dery', '02455566644', '0_1530700105.jpeg'),
(8, 'augustine dery', '02455866626', '1_1530700105.jpeg'),
(9, 'vivian dery', '02455566622', '2_1530700105.jpeg');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
